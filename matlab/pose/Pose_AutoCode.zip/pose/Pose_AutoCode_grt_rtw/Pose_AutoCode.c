/*
 * Pose_AutoCode.c
 *
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * Code generation for model "Pose_AutoCode".
 *
 * Model version              : 1.17
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Thu Feb 13 23:09:16 2020
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Pose_AutoCode.h"
#include "Pose_AutoCode_private.h"

/* Block signals (default storage) */
B_Pose_AutoCode_T Pose_AutoCode_B;

/* Block states (default storage) */
DW_Pose_AutoCode_T Pose_AutoCode_DW;

/* External inputs (root inport signals with default storage) */
ExtU_Pose_AutoCode_T Pose_AutoCode_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_Pose_AutoCode_T Pose_AutoCode_Y;

/* Real-time model */
RT_MODEL_Pose_AutoCode_T Pose_AutoCode_M_;
RT_MODEL_Pose_AutoCode_T *const Pose_AutoCode_M = &Pose_AutoCode_M_;

/*
 * Output and update for atomic system:
 *    '<S6>/TimeCompensator1'
 *    '<S6>/TimeCompensator10'
 *    '<S6>/TimeCompensator11'
 *    '<S6>/TimeCompensator12'
 *    '<S6>/TimeCompensator2'
 *    '<S6>/TimeCompensator3'
 *    '<S6>/TimeCompensator4'
 *    '<S6>/TimeCompensator5'
 *    '<S6>/TimeCompensator6'
 *    '<S6>/TimeCompensator7'
 *    ...
 */
void Pose_AutoCode_TimeCompensator1(real_T rtu_value_in, uint8_T rtu_status_in,
  B_TimeCompensator1_Pose_AutoC_T *localB)
{
  if (rtu_status_in == SIGNALSTATE_UNDEFINED) {
    localB->value = 0.0;
  } else if (rtu_status_in == SIGNALSTATE_INITIALIZING) {
    localB->value = 0.0;
  } else {
    localB->value = rtu_value_in;
  }
}

/* Model step function */
void Pose_AutoCode_step(void)
{
  /* Outport: '<Root>/pose_linearacceleration_signals' */
  Pose_AutoCode_Y.pose_linearacceleration_signals = 0.0;

  /* Outport: '<Root>/Out2' */
  Pose_AutoCode_Y.Out2 = 0.0;

  /* Outport: '<Root>/Out3' */
  Pose_AutoCode_Y.Out3 = 0.0;

  /* Outport: '<Root>/Out4' */
  Pose_AutoCode_Y.Out4 = 0.0;

  /* Outport: '<Root>/Out5' */
  Pose_AutoCode_Y.Out5 = 0.0;

  /* Outport: '<Root>/Out6' */
  Pose_AutoCode_Y.Out6 = 0.0;

  /* Outputs for Atomic SubSystem: '<S1>/TimeCompensate' */

  /* MATLAB Function: '<S6>/TimeCompensator1' incorporates:
   *  Inport: '<Root>/rotationrate1x_in_rms'
   *  Inport: '<Root>/rotationrate1x_in_status'
   *  Inport: '<Root>/rotationrate1x_in_type'
   *  Inport: '<Root>/rotationrate1x_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_hgi,
    Pose_AutoCode_U.status_pc, &Pose_AutoCode_B.sf_TimeCompensator1);

  /* MATLAB Function: '<S6>/TimeCompensator2' incorporates:
   *  Inport: '<Root>/rotationrate1y_in_rms'
   *  Inport: '<Root>/rotationrate1y_in_status'
   *  Inport: '<Root>/rotationrate1y_in_type'
   *  Inport: '<Root>/rotationrate1y_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_p,
    Pose_AutoCode_U.status_e, &Pose_AutoCode_B.sf_TimeCompensator2);

  /* MATLAB Function: '<S6>/TimeCompensator3' incorporates:
   *  Inport: '<Root>/rotationrate1z_in_rms'
   *  Inport: '<Root>/rotationrate1z_in_status'
   *  Inport: '<Root>/rotationrate1z_in_type'
   *  Inport: '<Root>/rotationrate1z_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_o,
    Pose_AutoCode_U.status_i, &Pose_AutoCode_B.sf_TimeCompensator3);

  /* MATLAB Function: '<S6>/TimeCompensator4' incorporates:
   *  Inport: '<Root>/rotationrate2x_in_rms'
   *  Inport: '<Root>/rotationrate2x_in_status'
   *  Inport: '<Root>/rotationrate2x_in_type1'
   *  Inport: '<Root>/rotationrate2x_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_kb,
    Pose_AutoCode_U.status_ic, &Pose_AutoCode_B.sf_TimeCompensator4);

  /* MATLAB Function: '<S6>/TimeCompensator5' incorporates:
   *  Inport: '<Root>/rotationrate2y_in_rms'
   *  Inport: '<Root>/rotationrate2y_in_status'
   *  Inport: '<Root>/rotationrate2y_in_type'
   *  Inport: '<Root>/rotationrate2y_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_il,
    Pose_AutoCode_U.status_f, &Pose_AutoCode_B.sf_TimeCompensator5);

  /* MATLAB Function: '<S6>/TimeCompensator6' incorporates:
   *  Inport: '<Root>/rotationrate2z_in_rms'
   *  Inport: '<Root>/rotationrate2z_in_status1'
   *  Inport: '<Root>/rotationrate2z_in_type'
   *  Inport: '<Root>/rotationrate2z_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_f,
    Pose_AutoCode_U.status_fn, &Pose_AutoCode_B.sf_TimeCompensator6);

  /* MATLAB Function: '<S6>/TimeCompensator7' incorporates:
   *  Inport: '<Root>/rotationrate3x_in_rms'
   *  Inport: '<Root>/rotationrate3x_in_status'
   *  Inport: '<Root>/rotationrate3x_in_type'
   *  Inport: '<Root>/rotationrate3x_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_br,
    Pose_AutoCode_U.status_p4, &Pose_AutoCode_B.sf_TimeCompensator7);

  /* MATLAB Function: '<S6>/TimeCompensator8' incorporates:
   *  Inport: '<Root>/rotationrate3y_in_rms'
   *  Inport: '<Root>/rotationrate3y_in_status'
   *  Inport: '<Root>/rotationrate3y_in_type'
   *  Inport: '<Root>/rotationrate3y_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_kg,
    Pose_AutoCode_U.status_lk, &Pose_AutoCode_B.sf_TimeCompensator8);

  /* MATLAB Function: '<S6>/TimeCompensator9' incorporates:
   *  Inport: '<Root>/rotationrate3z_in_rms'
   *  Inport: '<Root>/rotationrate3z_in_status'
   *  Inport: '<Root>/rotationrate3z_in_type'
   *  Inport: '<Root>/rotationrate3z_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_a,
    Pose_AutoCode_U.status_mm, &Pose_AutoCode_B.sf_TimeCompensator9);

  /* MATLAB Function: '<S6>/TimeCompensator10' incorporates:
   *  Inport: '<Root>/rotationrate4x_in_rms'
   *  Inport: '<Root>/rotationrate4x_in_status'
   *  Inport: '<Root>/rotationrate4x_in_type'
   *  Inport: '<Root>/rotationrate4x_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_a5,
    Pose_AutoCode_U.status_e1, &Pose_AutoCode_B.sf_TimeCompensator10);

  /* MATLAB Function: '<S6>/TimeCompensator11' incorporates:
   *  Inport: '<Root>/rotationrate4y_in_rms'
   *  Inport: '<Root>/rotationrate4y_in_status'
   *  Inport: '<Root>/rotationrate4y_in_type'
   *  Inport: '<Root>/rotationrate4y_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_od,
    Pose_AutoCode_U.status_bf, &Pose_AutoCode_B.sf_TimeCompensator11);

  /* MATLAB Function: '<S6>/TimeCompensator12' incorporates:
   *  Inport: '<Root>/rotationrate4z_in_rms'
   *  Inport: '<Root>/rotationrate4z_in_status'
   *  Inport: '<Root>/rotationrate4z_in_type'
   *  Inport: '<Root>/rotationrate4z_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_d5,
    Pose_AutoCode_U.status_m3, &Pose_AutoCode_B.sf_TimeCompensator12);

  /* MATLAB Function: '<S7>/TimeCompensator1' incorporates:
   *  Inport: '<Root>/accel1x_in_rms'
   *  Inport: '<Root>/accel1x_in_status'
   *  Inport: '<Root>/accel1x_in_type'
   *  Inport: '<Root>/accel1x_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value, Pose_AutoCode_U.status,
    &Pose_AutoCode_B.sf_TimeCompensator1_e);

  /* MATLAB Function: '<S7>/TimeCompensator2' incorporates:
   *  Inport: '<Root>/accel1y_in_rms'
   *  Inport: '<Root>/accel1y_in_status'
   *  Inport: '<Root>/accel1y_in_type'
   *  Inport: '<Root>/accel1y_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_j,
    Pose_AutoCode_U.status_d, &Pose_AutoCode_B.sf_TimeCompensator2_i);

  /* MATLAB Function: '<S7>/TimeCompensator3' incorporates:
   *  Inport: '<Root>/accel1z_in_rms'
   *  Inport: '<Root>/accel1z_in_status'
   *  Inport: '<Root>/accel1z_in_type'
   *  Inport: '<Root>/accel1z_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_d,
    Pose_AutoCode_U.status_p, &Pose_AutoCode_B.sf_TimeCompensator3_g);

  /* MATLAB Function: '<S7>/TimeCompensator4' incorporates:
   *  Inport: '<Root>/accel2x_in_rms'
   *  Inport: '<Root>/accel2x_in_status'
   *  Inport: '<Root>/accel2x_in_type'
   *  Inport: '<Root>/accel2x_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_h,
    Pose_AutoCode_U.status_k, &Pose_AutoCode_B.sf_TimeCompensator4_m);

  /* MATLAB Function: '<S7>/TimeCompensator5' incorporates:
   *  Inport: '<Root>/accel2y_in_rms'
   *  Inport: '<Root>/accel2y_in_status'
   *  Inport: '<Root>/accel2y_in_type'
   *  Inport: '<Root>/accel2y_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_i,
    Pose_AutoCode_U.status_n, &Pose_AutoCode_B.sf_TimeCompensator5_g);

  /* MATLAB Function: '<S7>/TimeCompensator6' incorporates:
   *  Inport: '<Root>/accel2z_in_rms'
   *  Inport: '<Root>/accel2z_in_status'
   *  Inport: '<Root>/accel2z_in_type'
   *  Inport: '<Root>/accel2z_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_b,
    Pose_AutoCode_U.status_l, &Pose_AutoCode_B.sf_TimeCompensator6_m);

  /* MATLAB Function: '<S7>/TimeCompensator7' incorporates:
   *  Inport: '<Root>/accel3x_in_rms'
   *  Inport: '<Root>/accel3x_in_status'
   *  Inport: '<Root>/accel3x_in_type'
   *  Inport: '<Root>/accel3x_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_ji,
    Pose_AutoCode_U.status_b, &Pose_AutoCode_B.sf_TimeCompensator7_f);

  /* MATLAB Function: '<S7>/TimeCompensator8' incorporates:
   *  Inport: '<Root>/accel3y_in_rms'
   *  Inport: '<Root>/accel3y_in_status'
   *  Inport: '<Root>/accel3y_in_type'
   *  Inport: '<Root>/accel3y_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_i0,
    Pose_AutoCode_U.status_a, &Pose_AutoCode_B.sf_TimeCompensator8_g);

  /* MATLAB Function: '<S7>/TimeCompensator9' incorporates:
   *  Inport: '<Root>/accel3z_in_rms'
   *  Inport: '<Root>/accel3z_in_status'
   *  Inport: '<Root>/accel3z_in_type'
   *  Inport: '<Root>/accel3z_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_n,
    Pose_AutoCode_U.status_h, &Pose_AutoCode_B.sf_TimeCompensator9_n);

  /* MATLAB Function: '<S7>/TimeCompensator10' incorporates:
   *  Inport: '<Root>/accel4x_in_rms'
   *  Inport: '<Root>/accel4x_in_status'
   *  Inport: '<Root>/accel4x_in_type'
   *  Inport: '<Root>/accel4x_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_k,
    Pose_AutoCode_U.status_m, &Pose_AutoCode_B.sf_TimeCompensator10_l);

  /* MATLAB Function: '<S7>/TimeCompensator11' incorporates:
   *  Inport: '<Root>/accel4y_in_rms'
   *  Inport: '<Root>/accel4y_in_status'
   *  Inport: '<Root>/accel4y_in_type'
   *  Inport: '<Root>/accel4y_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_h2,
    Pose_AutoCode_U.status_nm, &Pose_AutoCode_B.sf_TimeCompensator11_b);

  /* MATLAB Function: '<S7>/TimeCompensator12' incorporates:
   *  Inport: '<Root>/accel4z_in_rms'
   *  Inport: '<Root>/accel4z_in_status'
   *  Inport: '<Root>/accel4z_in_type'
   *  Inport: '<Root>/accel4z_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_hg,
    Pose_AutoCode_U.status_o, &Pose_AutoCode_B.sf_TimeCompensator12_i);

  /* MATLAB Function: '<S8>/TimeCompensator1' incorporates:
   *  Inport: '<Root>/mag1x_in_rms'
   *  Inport: '<Root>/mag1x_in_status'
   *  Inport: '<Root>/mag1x_in_type'
   *  Inport: '<Root>/mag1x_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_c,
    Pose_AutoCode_U.status_i1, &Pose_AutoCode_B.sf_TimeCompensator1_i);

  /* MATLAB Function: '<S8>/TimeCompensator2' incorporates:
   *  Inport: '<Root>/mag1y_in_rms'
   *  Inport: '<Root>/mag1y_in_status'
   *  Inport: '<Root>/mag1y_in_type'
   *  Inport: '<Root>/mag1y_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_jt,
    Pose_AutoCode_U.status_dg, &Pose_AutoCode_B.sf_TimeCompensator2_h);

  /* MATLAB Function: '<S8>/TimeCompensator3' incorporates:
   *  Inport: '<Root>/mag1z_in_rms'
   *  Inport: '<Root>/mag1z_in_status'
   *  Inport: '<Root>/mag1z_in_type'
   *  Inport: '<Root>/mag1z_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_je,
    Pose_AutoCode_U.status_ao, &Pose_AutoCode_B.sf_TimeCompensator3_n);

  /* MATLAB Function: '<S8>/TimeCompensator4' incorporates:
   *  Inport: '<Root>/mag2x_in_rms'
   *  Inport: '<Root>/mag2x_in_status'
   *  Inport: '<Root>/mag2x_in_type'
   *  Inport: '<Root>/mag2x_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_m,
    Pose_AutoCode_U.status_g, &Pose_AutoCode_B.sf_TimeCompensator4_h);

  /* MATLAB Function: '<S8>/TimeCompensator5' incorporates:
   *  Inport: '<Root>/mag2y_in_rms'
   *  Inport: '<Root>/mag2y_in_status'
   *  Inport: '<Root>/mag2y_in_type'
   *  Inport: '<Root>/mag2y_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_ps,
    Pose_AutoCode_U.status_gt, &Pose_AutoCode_B.sf_TimeCompensator5_i);

  /* MATLAB Function: '<S8>/TimeCompensator6' incorporates:
   *  Inport: '<Root>/mag2z_in_rms'
   *  Inport: '<Root>/mag2z_in_status'
   *  Inport: '<Root>/mag2z_in_type'
   *  Inport: '<Root>/mag2z_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_hu,
    Pose_AutoCode_U.status_j, &Pose_AutoCode_B.sf_TimeCompensator6_m2);

  /* MATLAB Function: '<S8>/TimeCompensator7' incorporates:
   *  Inport: '<Root>/mag3x_in_rms'
   *  Inport: '<Root>/mag3x_in_status'
   *  Inport: '<Root>/mag3x_in_type'
   *  Inport: '<Root>/mag3x_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_dz,
    Pose_AutoCode_U.status_k0, &Pose_AutoCode_B.sf_TimeCompensator7_o);

  /* MATLAB Function: '<S8>/TimeCompensator8' incorporates:
   *  Inport: '<Root>/mag3y_in_rms'
   *  Inport: '<Root>/mag3y_in_status'
   *  Inport: '<Root>/mag3y_in_type'
   *  Inport: '<Root>/mag3y_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_g,
    Pose_AutoCode_U.status_bd, &Pose_AutoCode_B.sf_TimeCompensator8_m);

  /* MATLAB Function: '<S8>/TimeCompensator9' incorporates:
   *  Inport: '<Root>/mag3z_in_rms'
   *  Inport: '<Root>/mag3z_in_status'
   *  Inport: '<Root>/mag3z_in_type'
   *  Inport: '<Root>/mag3z_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_md,
    Pose_AutoCode_U.status_ha, &Pose_AutoCode_B.sf_TimeCompensator9_d);

  /* MATLAB Function: '<S8>/TimeCompensator10' incorporates:
   *  Inport: '<Root>/mag4x_in_rms'
   *  Inport: '<Root>/mag4x_in_status'
   *  Inport: '<Root>/mag4x_in_type'
   *  Inport: '<Root>/mag4x_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_pn,
    Pose_AutoCode_U.status_ew, &Pose_AutoCode_B.sf_TimeCompensator10_g);

  /* MATLAB Function: '<S8>/TimeCompensator11' incorporates:
   *  Inport: '<Root>/mag4y_in_rms'
   *  Inport: '<Root>/mag4y_in_status'
   *  Inport: '<Root>/mag4y_in_type'
   *  Inport: '<Root>/mag4y_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_h2p,
    Pose_AutoCode_U.status_jo, &Pose_AutoCode_B.sf_TimeCompensator11_e);

  /* MATLAB Function: '<S8>/TimeCompensator12' incorporates:
   *  Inport: '<Root>/mag4z_in_rms'
   *  Inport: '<Root>/mag4z_in_status'
   *  Inport: '<Root>/mag4z_in_type'
   *  Inport: '<Root>/mag4z_in_value'
   */
  Pose_AutoCode_TimeCompensator1(Pose_AutoCode_U.value_n4,
    Pose_AutoCode_U.status_gl, &Pose_AutoCode_B.sf_TimeCompensator12_g);

  /* End of Outputs for SubSystem: '<S1>/TimeCompensate' */

  /* Matfile logging */
  rt_UpdateTXYLogVars(Pose_AutoCode_M->rtwLogInfo,
                      (&Pose_AutoCode_M->Timing.taskTime0));

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.2s, 0.0s] */
    if ((rtmGetTFinal(Pose_AutoCode_M)!=-1) &&
        !((rtmGetTFinal(Pose_AutoCode_M)-Pose_AutoCode_M->Timing.taskTime0) >
          Pose_AutoCode_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(Pose_AutoCode_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Pose_AutoCode_M->Timing.clockTick0)) {
    ++Pose_AutoCode_M->Timing.clockTickH0;
  }

  Pose_AutoCode_M->Timing.taskTime0 = Pose_AutoCode_M->Timing.clockTick0 *
    Pose_AutoCode_M->Timing.stepSize0 + Pose_AutoCode_M->Timing.clockTickH0 *
    Pose_AutoCode_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void Pose_AutoCode_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)Pose_AutoCode_M, 0,
                sizeof(RT_MODEL_Pose_AutoCode_T));
  rtmSetTFinal(Pose_AutoCode_M, 10.0);
  Pose_AutoCode_M->Timing.stepSize0 = 0.2;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    Pose_AutoCode_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(Pose_AutoCode_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(Pose_AutoCode_M->rtwLogInfo, (NULL));
    rtliSetLogT(Pose_AutoCode_M->rtwLogInfo, "tout");
    rtliSetLogX(Pose_AutoCode_M->rtwLogInfo, "");
    rtliSetLogXFinal(Pose_AutoCode_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(Pose_AutoCode_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(Pose_AutoCode_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(Pose_AutoCode_M->rtwLogInfo, 0);
    rtliSetLogDecimation(Pose_AutoCode_M->rtwLogInfo, 1);
    rtliSetLogY(Pose_AutoCode_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(Pose_AutoCode_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(Pose_AutoCode_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) memset(((void *) &Pose_AutoCode_B), 0,
                sizeof(B_Pose_AutoCode_T));

  /* states (dwork) */
  (void) memset((void *)&Pose_AutoCode_DW, 0,
                sizeof(DW_Pose_AutoCode_T));

  /* external inputs */
  (void)memset(&Pose_AutoCode_U, 0, sizeof(ExtU_Pose_AutoCode_T));

  /* external outputs */
  (void) memset((void *)&Pose_AutoCode_Y, 0,
                sizeof(ExtY_Pose_AutoCode_T));

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(Pose_AutoCode_M->rtwLogInfo, 0.0,
    rtmGetTFinal(Pose_AutoCode_M), Pose_AutoCode_M->Timing.stepSize0,
    (&rtmGetErrorStatus(Pose_AutoCode_M)));
}

/* Model terminate function */
void Pose_AutoCode_terminate(void)
{
  /* (no terminate code required) */
}
