/*
 * PoseExecutor.h
 *
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * Code generation for model "PoseExecutor".
 *
 * Model version              : 1.122
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C++ source code generated on : Mon Feb 10 20:47:00 2020
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_PoseExecutor_h_
#define RTW_HEADER_PoseExecutor_h_
#include <cmath>
#include <cstring>
#ifndef PoseExecutor_COMMON_INCLUDES_
# define PoseExecutor_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* PoseExecutor_COMMON_INCLUDES_ */

#include "PoseExecutor_types.h"

/* Shared type includes */
#include "multiword_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

/* Block signals for system '<Root>/Signal to Bus' */
typedef struct {
  real_T IndexVector1;                 /* '<S94>/Index Vector1' */
  real_T IndexVector1_f;               /* '<S93>/Index Vector1' */
  real_T IndexVector1_k;               /* '<S92>/Index Vector1' */
  real_T IndexVector1_l;               /* '<S90>/Index Vector1' */
} B_SignaltoBus_PoseExecutor_T;

/* Block signals (default storage) */
typedef struct {
  B_SignaltoBus_PoseExecutor_T SignaltoBus9;/* '<Root>/Signal to Bus9' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus8;/* '<Root>/Signal to Bus8' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus7;/* '<Root>/Signal to Bus7' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus6;/* '<Root>/Signal to Bus6' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus5;/* '<Root>/Signal to Bus5' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus4;/* '<Root>/Signal to Bus4' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus35;/* '<Root>/Signal to Bus35' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus34;/* '<Root>/Signal to Bus34' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus33;/* '<Root>/Signal to Bus33' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus32;/* '<Root>/Signal to Bus32' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus31;/* '<Root>/Signal to Bus31' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus30;/* '<Root>/Signal to Bus30' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus3;/* '<Root>/Signal to Bus3' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus29;/* '<Root>/Signal to Bus29' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus28;/* '<Root>/Signal to Bus28' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus27;/* '<Root>/Signal to Bus27' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus26;/* '<Root>/Signal to Bus26' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus25;/* '<Root>/Signal to Bus25' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus24;/* '<Root>/Signal to Bus24' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus23;/* '<Root>/Signal to Bus23' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus22;/* '<Root>/Signal to Bus22' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus21;/* '<Root>/Signal to Bus21' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus20;/* '<Root>/Signal to Bus20' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus2;/* '<Root>/Signal to Bus2' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus19;/* '<Root>/Signal to Bus19' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus18;/* '<Root>/Signal to Bus18' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus17;/* '<Root>/Signal to Bus17' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus16;/* '<Root>/Signal to Bus16' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus15;/* '<Root>/Signal to Bus15' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus14;/* '<Root>/Signal to Bus14' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus13;/* '<Root>/Signal to Bus13' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus12;/* '<Root>/Signal to Bus12' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus11;/* '<Root>/Signal to Bus11' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus10;/* '<Root>/Signal to Bus10' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus1;/* '<Root>/Signal to Bus1' */
  B_SignaltoBus_PoseExecutor_T SignaltoBus;/* '<Root>/Signal to Bus' */
} B_PoseExecutor_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace_PWORK;               /* '<Root>/From Workspace' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace1_PWORK;              /* '<Root>/From Workspace1' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace10_PWORK;             /* '<Root>/From Workspace10' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace11_PWORK;             /* '<Root>/From Workspace11' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace12_PWORK;             /* '<Root>/From Workspace12' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace13_PWORK;             /* '<Root>/From Workspace13' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace14_PWORK;             /* '<Root>/From Workspace14' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace15_PWORK;             /* '<Root>/From Workspace15' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace16_PWORK;             /* '<Root>/From Workspace16' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace17_PWORK;             /* '<Root>/From Workspace17' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace18_PWORK;             /* '<Root>/From Workspace18' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace19_PWORK;             /* '<Root>/From Workspace19' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace2_PWORK;              /* '<Root>/From Workspace2' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace20_PWORK;             /* '<Root>/From Workspace20' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace21_PWORK;             /* '<Root>/From Workspace21' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace22_PWORK;             /* '<Root>/From Workspace22' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace23_PWORK;             /* '<Root>/From Workspace23' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace24_PWORK;             /* '<Root>/From Workspace24' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace25_PWORK;             /* '<Root>/From Workspace25' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace26_PWORK;             /* '<Root>/From Workspace26' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace27_PWORK;             /* '<Root>/From Workspace27' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace28_PWORK;             /* '<Root>/From Workspace28' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace29_PWORK;             /* '<Root>/From Workspace29' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace3_PWORK;              /* '<Root>/From Workspace3' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace30_PWORK;             /* '<Root>/From Workspace30' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace31_PWORK;             /* '<Root>/From Workspace31' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace32_PWORK;             /* '<Root>/From Workspace32' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace33_PWORK;             /* '<Root>/From Workspace33' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace34_PWORK;             /* '<Root>/From Workspace34' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace35_PWORK;             /* '<Root>/From Workspace35' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace4_PWORK;              /* '<Root>/From Workspace4' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace5_PWORK;              /* '<Root>/From Workspace5' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace6_PWORK;              /* '<Root>/From Workspace6' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace7_PWORK;              /* '<Root>/From Workspace7' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace8_PWORK;              /* '<Root>/From Workspace8' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWorkspace9_PWORK;              /* '<Root>/From Workspace9' */

  struct {
    int_T PrevIndex;
  } FromWorkspace_IWORK;               /* '<Root>/From Workspace' */

  struct {
    int_T PrevIndex;
  } FromWorkspace1_IWORK;              /* '<Root>/From Workspace1' */

  struct {
    int_T PrevIndex;
  } FromWorkspace10_IWORK;             /* '<Root>/From Workspace10' */

  struct {
    int_T PrevIndex;
  } FromWorkspace11_IWORK;             /* '<Root>/From Workspace11' */

  struct {
    int_T PrevIndex;
  } FromWorkspace12_IWORK;             /* '<Root>/From Workspace12' */

  struct {
    int_T PrevIndex;
  } FromWorkspace13_IWORK;             /* '<Root>/From Workspace13' */

  struct {
    int_T PrevIndex;
  } FromWorkspace14_IWORK;             /* '<Root>/From Workspace14' */

  struct {
    int_T PrevIndex;
  } FromWorkspace15_IWORK;             /* '<Root>/From Workspace15' */

  struct {
    int_T PrevIndex;
  } FromWorkspace16_IWORK;             /* '<Root>/From Workspace16' */

  struct {
    int_T PrevIndex;
  } FromWorkspace17_IWORK;             /* '<Root>/From Workspace17' */

  struct {
    int_T PrevIndex;
  } FromWorkspace18_IWORK;             /* '<Root>/From Workspace18' */

  struct {
    int_T PrevIndex;
  } FromWorkspace19_IWORK;             /* '<Root>/From Workspace19' */

  struct {
    int_T PrevIndex;
  } FromWorkspace2_IWORK;              /* '<Root>/From Workspace2' */

  struct {
    int_T PrevIndex;
  } FromWorkspace20_IWORK;             /* '<Root>/From Workspace20' */

  struct {
    int_T PrevIndex;
  } FromWorkspace21_IWORK;             /* '<Root>/From Workspace21' */

  struct {
    int_T PrevIndex;
  } FromWorkspace22_IWORK;             /* '<Root>/From Workspace22' */

  struct {
    int_T PrevIndex;
  } FromWorkspace23_IWORK;             /* '<Root>/From Workspace23' */

  struct {
    int_T PrevIndex;
  } FromWorkspace24_IWORK;             /* '<Root>/From Workspace24' */

  struct {
    int_T PrevIndex;
  } FromWorkspace25_IWORK;             /* '<Root>/From Workspace25' */

  struct {
    int_T PrevIndex;
  } FromWorkspace26_IWORK;             /* '<Root>/From Workspace26' */

  struct {
    int_T PrevIndex;
  } FromWorkspace27_IWORK;             /* '<Root>/From Workspace27' */

  struct {
    int_T PrevIndex;
  } FromWorkspace28_IWORK;             /* '<Root>/From Workspace28' */

  struct {
    int_T PrevIndex;
  } FromWorkspace29_IWORK;             /* '<Root>/From Workspace29' */

  struct {
    int_T PrevIndex;
  } FromWorkspace3_IWORK;              /* '<Root>/From Workspace3' */

  struct {
    int_T PrevIndex;
  } FromWorkspace30_IWORK;             /* '<Root>/From Workspace30' */

  struct {
    int_T PrevIndex;
  } FromWorkspace31_IWORK;             /* '<Root>/From Workspace31' */

  struct {
    int_T PrevIndex;
  } FromWorkspace32_IWORK;             /* '<Root>/From Workspace32' */

  struct {
    int_T PrevIndex;
  } FromWorkspace33_IWORK;             /* '<Root>/From Workspace33' */

  struct {
    int_T PrevIndex;
  } FromWorkspace34_IWORK;             /* '<Root>/From Workspace34' */

  struct {
    int_T PrevIndex;
  } FromWorkspace35_IWORK;             /* '<Root>/From Workspace35' */

  struct {
    int_T PrevIndex;
  } FromWorkspace4_IWORK;              /* '<Root>/From Workspace4' */

  struct {
    int_T PrevIndex;
  } FromWorkspace5_IWORK;              /* '<Root>/From Workspace5' */

  struct {
    int_T PrevIndex;
  } FromWorkspace6_IWORK;              /* '<Root>/From Workspace6' */

  struct {
    int_T PrevIndex;
  } FromWorkspace7_IWORK;              /* '<Root>/From Workspace7' */

  struct {
    int_T PrevIndex;
  } FromWorkspace8_IWORK;              /* '<Root>/From Workspace8' */

  struct {
    int_T PrevIndex;
  } FromWorkspace9_IWORK;              /* '<Root>/From Workspace9' */
} DW_PoseExecutor_T;

/* Parameters for system: '<Root>/Signal to Bus' */
struct P_SignaltoBus_PoseExecutor_T_ {
  real_T Constant1_Value;              /* Expression: 3
                                        * Referenced by: '<S90>/Constant1'
                                        */
  real_T Constant1_Value_j;            /* Expression: 2
                                        * Referenced by: '<S92>/Constant1'
                                        */
  real_T Constant1_Value_d;            /* Expression: 0
                                        * Referenced by: '<S93>/Constant1'
                                        */
  real_T Constant1_Value_o;            /* Expression: 1
                                        * Referenced by: '<S94>/Constant1'
                                        */
};

/* Parameters (default storage) */
struct P_PoseExecutor_T_ {
  P_SignaltoBus_PoseExecutor_T SignaltoBus9;/* '<Root>/Signal to Bus9' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus8;/* '<Root>/Signal to Bus8' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus7;/* '<Root>/Signal to Bus7' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus6;/* '<Root>/Signal to Bus6' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus5;/* '<Root>/Signal to Bus5' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus4;/* '<Root>/Signal to Bus4' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus35;/* '<Root>/Signal to Bus35' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus34;/* '<Root>/Signal to Bus34' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus33;/* '<Root>/Signal to Bus33' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus32;/* '<Root>/Signal to Bus32' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus31;/* '<Root>/Signal to Bus31' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus30;/* '<Root>/Signal to Bus30' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus3;/* '<Root>/Signal to Bus3' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus29;/* '<Root>/Signal to Bus29' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus28;/* '<Root>/Signal to Bus28' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus27;/* '<Root>/Signal to Bus27' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus26;/* '<Root>/Signal to Bus26' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus25;/* '<Root>/Signal to Bus25' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus24;/* '<Root>/Signal to Bus24' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus23;/* '<Root>/Signal to Bus23' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus22;/* '<Root>/Signal to Bus22' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus21;/* '<Root>/Signal to Bus21' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus20;/* '<Root>/Signal to Bus20' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus2;/* '<Root>/Signal to Bus2' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus19;/* '<Root>/Signal to Bus19' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus18;/* '<Root>/Signal to Bus18' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus17;/* '<Root>/Signal to Bus17' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus16;/* '<Root>/Signal to Bus16' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus15;/* '<Root>/Signal to Bus15' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus14;/* '<Root>/Signal to Bus14' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus13;/* '<Root>/Signal to Bus13' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus12;/* '<Root>/Signal to Bus12' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus11;/* '<Root>/Signal to Bus11' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus10;/* '<Root>/Signal to Bus10' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus1;/* '<Root>/Signal to Bus1' */
  P_SignaltoBus_PoseExecutor_T SignaltoBus;/* '<Root>/Signal to Bus' */
};

/* Real-time Model Data Structure */
struct tag_RTM_PoseExecutor_T {
  const char_T *errorStatus;
  RTWSolverInfo solverInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    SimTimeStep simTimeStep;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Class declaration for model PoseExecutor */
class PoseExecutorModelClass {
  /* public data and function members */
 public:
  /* model initialize function */
  void initialize();

  /* model step function */
  void step();

  /* model terminate function */
  void terminate();

  /* Constructor */
  PoseExecutorModelClass();

  /* Destructor */
  ~PoseExecutorModelClass();

  /* Real-Time Model get method */
  RT_MODEL_PoseExecutor_T * getRTM();

  /* private data and function members */
 private:
  /* Tunable parameters */
  static P_PoseExecutor_T PoseExecutor_P;

  /* Block signals */
  B_PoseExecutor_T PoseExecutor_B;

  /* Block states */
  DW_PoseExecutor_T PoseExecutor_DW;

  /* Real-Time Model */
  RT_MODEL_PoseExecutor_T PoseExecutor_M;

  /* private member function(s) for subsystem '<Root>/Signal to Bus'*/
  void PoseExecutor_SignaltoBus(const real_T rtu_signal_in[5],
    B_SignaltoBus_PoseExecutor_T *localB, P_SignaltoBus_PoseExecutor_T *localP);
};

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'PoseExecutor'
 * '<S1>'   : 'PoseExecutor/PoseSystem'
 * '<S2>'   : 'PoseExecutor/Signal to Bus'
 * '<S3>'   : 'PoseExecutor/Signal to Bus1'
 * '<S4>'   : 'PoseExecutor/Signal to Bus10'
 * '<S5>'   : 'PoseExecutor/Signal to Bus11'
 * '<S6>'   : 'PoseExecutor/Signal to Bus12'
 * '<S7>'   : 'PoseExecutor/Signal to Bus13'
 * '<S8>'   : 'PoseExecutor/Signal to Bus14'
 * '<S9>'   : 'PoseExecutor/Signal to Bus15'
 * '<S10>'  : 'PoseExecutor/Signal to Bus16'
 * '<S11>'  : 'PoseExecutor/Signal to Bus17'
 * '<S12>'  : 'PoseExecutor/Signal to Bus18'
 * '<S13>'  : 'PoseExecutor/Signal to Bus19'
 * '<S14>'  : 'PoseExecutor/Signal to Bus2'
 * '<S15>'  : 'PoseExecutor/Signal to Bus20'
 * '<S16>'  : 'PoseExecutor/Signal to Bus21'
 * '<S17>'  : 'PoseExecutor/Signal to Bus22'
 * '<S18>'  : 'PoseExecutor/Signal to Bus23'
 * '<S19>'  : 'PoseExecutor/Signal to Bus24'
 * '<S20>'  : 'PoseExecutor/Signal to Bus25'
 * '<S21>'  : 'PoseExecutor/Signal to Bus26'
 * '<S22>'  : 'PoseExecutor/Signal to Bus27'
 * '<S23>'  : 'PoseExecutor/Signal to Bus28'
 * '<S24>'  : 'PoseExecutor/Signal to Bus29'
 * '<S25>'  : 'PoseExecutor/Signal to Bus3'
 * '<S26>'  : 'PoseExecutor/Signal to Bus30'
 * '<S27>'  : 'PoseExecutor/Signal to Bus31'
 * '<S28>'  : 'PoseExecutor/Signal to Bus32'
 * '<S29>'  : 'PoseExecutor/Signal to Bus33'
 * '<S30>'  : 'PoseExecutor/Signal to Bus34'
 * '<S31>'  : 'PoseExecutor/Signal to Bus35'
 * '<S32>'  : 'PoseExecutor/Signal to Bus4'
 * '<S33>'  : 'PoseExecutor/Signal to Bus5'
 * '<S34>'  : 'PoseExecutor/Signal to Bus6'
 * '<S35>'  : 'PoseExecutor/Signal to Bus7'
 * '<S36>'  : 'PoseExecutor/Signal to Bus8'
 * '<S37>'  : 'PoseExecutor/Signal to Bus9'
 * '<S38>'  : 'PoseExecutor/PoseSystem/PoseAccelerationBlock'
 * '<S39>'  : 'PoseExecutor/PoseSystem/SensorPostProcessing'
 * '<S40>'  : 'PoseExecutor/PoseSystem/SignalLinker'
 * '<S41>'  : 'PoseExecutor/PoseSystem/TimeCompensate'
 * '<S42>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator'
 * '<S43>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator1'
 * '<S44>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator10'
 * '<S45>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator11'
 * '<S46>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator2'
 * '<S47>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator3'
 * '<S48>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator4'
 * '<S49>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator5'
 * '<S50>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator6'
 * '<S51>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator7'
 * '<S52>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator8'
 * '<S53>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator9'
 * '<S54>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator/MATLAB Function'
 * '<S55>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator/MATLAB Function1'
 * '<S56>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator/MATLAB Function2'
 * '<S57>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator1/MATLAB Function'
 * '<S58>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator1/MATLAB Function1'
 * '<S59>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator1/MATLAB Function2'
 * '<S60>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator10/MATLAB Function'
 * '<S61>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator10/MATLAB Function1'
 * '<S62>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator10/MATLAB Function2'
 * '<S63>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator11/MATLAB Function'
 * '<S64>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator11/MATLAB Function1'
 * '<S65>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator11/MATLAB Function2'
 * '<S66>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator2/MATLAB Function'
 * '<S67>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator2/MATLAB Function1'
 * '<S68>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator2/MATLAB Function2'
 * '<S69>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator3/MATLAB Function'
 * '<S70>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator3/MATLAB Function1'
 * '<S71>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator3/MATLAB Function2'
 * '<S72>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator4/MATLAB Function'
 * '<S73>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator4/MATLAB Function1'
 * '<S74>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator4/MATLAB Function2'
 * '<S75>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator5/MATLAB Function'
 * '<S76>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator5/MATLAB Function1'
 * '<S77>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator5/MATLAB Function2'
 * '<S78>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator6/MATLAB Function'
 * '<S79>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator6/MATLAB Function1'
 * '<S80>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator6/MATLAB Function2'
 * '<S81>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator7/MATLAB Function'
 * '<S82>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator7/MATLAB Function1'
 * '<S83>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator7/MATLAB Function2'
 * '<S84>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator8/MATLAB Function'
 * '<S85>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator8/MATLAB Function1'
 * '<S86>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator8/MATLAB Function2'
 * '<S87>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator9/MATLAB Function'
 * '<S88>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator9/MATLAB Function1'
 * '<S89>'  : 'PoseExecutor/PoseSystem/TimeCompensate/Time Compensator9/MATLAB Function2'
 * '<S90>'  : 'PoseExecutor/Signal to Bus/Get Signal RMS1'
 * '<S91>'  : 'PoseExecutor/Signal to Bus/Get Signal Sequence Number'
 * '<S92>'  : 'PoseExecutor/Signal to Bus/Get Signal Status1'
 * '<S93>'  : 'PoseExecutor/Signal to Bus/Get Signal Type1'
 * '<S94>'  : 'PoseExecutor/Signal to Bus/Get Signal Value1'
 * '<S95>'  : 'PoseExecutor/Signal to Bus1/Get Signal RMS1'
 * '<S96>'  : 'PoseExecutor/Signal to Bus1/Get Signal Sequence Number'
 * '<S97>'  : 'PoseExecutor/Signal to Bus1/Get Signal Status1'
 * '<S98>'  : 'PoseExecutor/Signal to Bus1/Get Signal Type1'
 * '<S99>'  : 'PoseExecutor/Signal to Bus1/Get Signal Value1'
 * '<S100>' : 'PoseExecutor/Signal to Bus10/Get Signal RMS1'
 * '<S101>' : 'PoseExecutor/Signal to Bus10/Get Signal Sequence Number'
 * '<S102>' : 'PoseExecutor/Signal to Bus10/Get Signal Status1'
 * '<S103>' : 'PoseExecutor/Signal to Bus10/Get Signal Type1'
 * '<S104>' : 'PoseExecutor/Signal to Bus10/Get Signal Value1'
 * '<S105>' : 'PoseExecutor/Signal to Bus11/Get Signal RMS1'
 * '<S106>' : 'PoseExecutor/Signal to Bus11/Get Signal Sequence Number'
 * '<S107>' : 'PoseExecutor/Signal to Bus11/Get Signal Status1'
 * '<S108>' : 'PoseExecutor/Signal to Bus11/Get Signal Type1'
 * '<S109>' : 'PoseExecutor/Signal to Bus11/Get Signal Value1'
 * '<S110>' : 'PoseExecutor/Signal to Bus12/Get Signal RMS1'
 * '<S111>' : 'PoseExecutor/Signal to Bus12/Get Signal Sequence Number'
 * '<S112>' : 'PoseExecutor/Signal to Bus12/Get Signal Status1'
 * '<S113>' : 'PoseExecutor/Signal to Bus12/Get Signal Type1'
 * '<S114>' : 'PoseExecutor/Signal to Bus12/Get Signal Value1'
 * '<S115>' : 'PoseExecutor/Signal to Bus13/Get Signal RMS1'
 * '<S116>' : 'PoseExecutor/Signal to Bus13/Get Signal Sequence Number'
 * '<S117>' : 'PoseExecutor/Signal to Bus13/Get Signal Status1'
 * '<S118>' : 'PoseExecutor/Signal to Bus13/Get Signal Type1'
 * '<S119>' : 'PoseExecutor/Signal to Bus13/Get Signal Value1'
 * '<S120>' : 'PoseExecutor/Signal to Bus14/Get Signal RMS1'
 * '<S121>' : 'PoseExecutor/Signal to Bus14/Get Signal Sequence Number'
 * '<S122>' : 'PoseExecutor/Signal to Bus14/Get Signal Status1'
 * '<S123>' : 'PoseExecutor/Signal to Bus14/Get Signal Type1'
 * '<S124>' : 'PoseExecutor/Signal to Bus14/Get Signal Value1'
 * '<S125>' : 'PoseExecutor/Signal to Bus15/Get Signal RMS1'
 * '<S126>' : 'PoseExecutor/Signal to Bus15/Get Signal Sequence Number'
 * '<S127>' : 'PoseExecutor/Signal to Bus15/Get Signal Status1'
 * '<S128>' : 'PoseExecutor/Signal to Bus15/Get Signal Type1'
 * '<S129>' : 'PoseExecutor/Signal to Bus15/Get Signal Value1'
 * '<S130>' : 'PoseExecutor/Signal to Bus16/Get Signal RMS1'
 * '<S131>' : 'PoseExecutor/Signal to Bus16/Get Signal Sequence Number'
 * '<S132>' : 'PoseExecutor/Signal to Bus16/Get Signal Status1'
 * '<S133>' : 'PoseExecutor/Signal to Bus16/Get Signal Type1'
 * '<S134>' : 'PoseExecutor/Signal to Bus16/Get Signal Value1'
 * '<S135>' : 'PoseExecutor/Signal to Bus17/Get Signal RMS1'
 * '<S136>' : 'PoseExecutor/Signal to Bus17/Get Signal Sequence Number'
 * '<S137>' : 'PoseExecutor/Signal to Bus17/Get Signal Status1'
 * '<S138>' : 'PoseExecutor/Signal to Bus17/Get Signal Type1'
 * '<S139>' : 'PoseExecutor/Signal to Bus17/Get Signal Value1'
 * '<S140>' : 'PoseExecutor/Signal to Bus18/Get Signal RMS1'
 * '<S141>' : 'PoseExecutor/Signal to Bus18/Get Signal Sequence Number'
 * '<S142>' : 'PoseExecutor/Signal to Bus18/Get Signal Status1'
 * '<S143>' : 'PoseExecutor/Signal to Bus18/Get Signal Type1'
 * '<S144>' : 'PoseExecutor/Signal to Bus18/Get Signal Value1'
 * '<S145>' : 'PoseExecutor/Signal to Bus19/Get Signal RMS1'
 * '<S146>' : 'PoseExecutor/Signal to Bus19/Get Signal Sequence Number'
 * '<S147>' : 'PoseExecutor/Signal to Bus19/Get Signal Status1'
 * '<S148>' : 'PoseExecutor/Signal to Bus19/Get Signal Type1'
 * '<S149>' : 'PoseExecutor/Signal to Bus19/Get Signal Value1'
 * '<S150>' : 'PoseExecutor/Signal to Bus2/Get Signal RMS1'
 * '<S151>' : 'PoseExecutor/Signal to Bus2/Get Signal Sequence Number'
 * '<S152>' : 'PoseExecutor/Signal to Bus2/Get Signal Status1'
 * '<S153>' : 'PoseExecutor/Signal to Bus2/Get Signal Type1'
 * '<S154>' : 'PoseExecutor/Signal to Bus2/Get Signal Value1'
 * '<S155>' : 'PoseExecutor/Signal to Bus20/Get Signal RMS1'
 * '<S156>' : 'PoseExecutor/Signal to Bus20/Get Signal Sequence Number'
 * '<S157>' : 'PoseExecutor/Signal to Bus20/Get Signal Status1'
 * '<S158>' : 'PoseExecutor/Signal to Bus20/Get Signal Type1'
 * '<S159>' : 'PoseExecutor/Signal to Bus20/Get Signal Value1'
 * '<S160>' : 'PoseExecutor/Signal to Bus21/Get Signal RMS1'
 * '<S161>' : 'PoseExecutor/Signal to Bus21/Get Signal Sequence Number'
 * '<S162>' : 'PoseExecutor/Signal to Bus21/Get Signal Status1'
 * '<S163>' : 'PoseExecutor/Signal to Bus21/Get Signal Type1'
 * '<S164>' : 'PoseExecutor/Signal to Bus21/Get Signal Value1'
 * '<S165>' : 'PoseExecutor/Signal to Bus22/Get Signal RMS1'
 * '<S166>' : 'PoseExecutor/Signal to Bus22/Get Signal Sequence Number'
 * '<S167>' : 'PoseExecutor/Signal to Bus22/Get Signal Status1'
 * '<S168>' : 'PoseExecutor/Signal to Bus22/Get Signal Type1'
 * '<S169>' : 'PoseExecutor/Signal to Bus22/Get Signal Value1'
 * '<S170>' : 'PoseExecutor/Signal to Bus23/Get Signal RMS1'
 * '<S171>' : 'PoseExecutor/Signal to Bus23/Get Signal Sequence Number'
 * '<S172>' : 'PoseExecutor/Signal to Bus23/Get Signal Status1'
 * '<S173>' : 'PoseExecutor/Signal to Bus23/Get Signal Type1'
 * '<S174>' : 'PoseExecutor/Signal to Bus23/Get Signal Value1'
 * '<S175>' : 'PoseExecutor/Signal to Bus24/Get Signal RMS1'
 * '<S176>' : 'PoseExecutor/Signal to Bus24/Get Signal Sequence Number'
 * '<S177>' : 'PoseExecutor/Signal to Bus24/Get Signal Status1'
 * '<S178>' : 'PoseExecutor/Signal to Bus24/Get Signal Type1'
 * '<S179>' : 'PoseExecutor/Signal to Bus24/Get Signal Value1'
 * '<S180>' : 'PoseExecutor/Signal to Bus25/Get Signal RMS1'
 * '<S181>' : 'PoseExecutor/Signal to Bus25/Get Signal Sequence Number'
 * '<S182>' : 'PoseExecutor/Signal to Bus25/Get Signal Status1'
 * '<S183>' : 'PoseExecutor/Signal to Bus25/Get Signal Type1'
 * '<S184>' : 'PoseExecutor/Signal to Bus25/Get Signal Value1'
 * '<S185>' : 'PoseExecutor/Signal to Bus26/Get Signal RMS1'
 * '<S186>' : 'PoseExecutor/Signal to Bus26/Get Signal Sequence Number'
 * '<S187>' : 'PoseExecutor/Signal to Bus26/Get Signal Status1'
 * '<S188>' : 'PoseExecutor/Signal to Bus26/Get Signal Type1'
 * '<S189>' : 'PoseExecutor/Signal to Bus26/Get Signal Value1'
 * '<S190>' : 'PoseExecutor/Signal to Bus27/Get Signal RMS1'
 * '<S191>' : 'PoseExecutor/Signal to Bus27/Get Signal Sequence Number'
 * '<S192>' : 'PoseExecutor/Signal to Bus27/Get Signal Status1'
 * '<S193>' : 'PoseExecutor/Signal to Bus27/Get Signal Type1'
 * '<S194>' : 'PoseExecutor/Signal to Bus27/Get Signal Value1'
 * '<S195>' : 'PoseExecutor/Signal to Bus28/Get Signal RMS1'
 * '<S196>' : 'PoseExecutor/Signal to Bus28/Get Signal Sequence Number'
 * '<S197>' : 'PoseExecutor/Signal to Bus28/Get Signal Status1'
 * '<S198>' : 'PoseExecutor/Signal to Bus28/Get Signal Type1'
 * '<S199>' : 'PoseExecutor/Signal to Bus28/Get Signal Value1'
 * '<S200>' : 'PoseExecutor/Signal to Bus29/Get Signal RMS1'
 * '<S201>' : 'PoseExecutor/Signal to Bus29/Get Signal Sequence Number'
 * '<S202>' : 'PoseExecutor/Signal to Bus29/Get Signal Status1'
 * '<S203>' : 'PoseExecutor/Signal to Bus29/Get Signal Type1'
 * '<S204>' : 'PoseExecutor/Signal to Bus29/Get Signal Value1'
 * '<S205>' : 'PoseExecutor/Signal to Bus3/Get Signal RMS1'
 * '<S206>' : 'PoseExecutor/Signal to Bus3/Get Signal Sequence Number'
 * '<S207>' : 'PoseExecutor/Signal to Bus3/Get Signal Status1'
 * '<S208>' : 'PoseExecutor/Signal to Bus3/Get Signal Type1'
 * '<S209>' : 'PoseExecutor/Signal to Bus3/Get Signal Value1'
 * '<S210>' : 'PoseExecutor/Signal to Bus30/Get Signal RMS1'
 * '<S211>' : 'PoseExecutor/Signal to Bus30/Get Signal Sequence Number'
 * '<S212>' : 'PoseExecutor/Signal to Bus30/Get Signal Status1'
 * '<S213>' : 'PoseExecutor/Signal to Bus30/Get Signal Type1'
 * '<S214>' : 'PoseExecutor/Signal to Bus30/Get Signal Value1'
 * '<S215>' : 'PoseExecutor/Signal to Bus31/Get Signal RMS1'
 * '<S216>' : 'PoseExecutor/Signal to Bus31/Get Signal Sequence Number'
 * '<S217>' : 'PoseExecutor/Signal to Bus31/Get Signal Status1'
 * '<S218>' : 'PoseExecutor/Signal to Bus31/Get Signal Type1'
 * '<S219>' : 'PoseExecutor/Signal to Bus31/Get Signal Value1'
 * '<S220>' : 'PoseExecutor/Signal to Bus32/Get Signal RMS1'
 * '<S221>' : 'PoseExecutor/Signal to Bus32/Get Signal Sequence Number'
 * '<S222>' : 'PoseExecutor/Signal to Bus32/Get Signal Status1'
 * '<S223>' : 'PoseExecutor/Signal to Bus32/Get Signal Type1'
 * '<S224>' : 'PoseExecutor/Signal to Bus32/Get Signal Value1'
 * '<S225>' : 'PoseExecutor/Signal to Bus33/Get Signal RMS1'
 * '<S226>' : 'PoseExecutor/Signal to Bus33/Get Signal Sequence Number'
 * '<S227>' : 'PoseExecutor/Signal to Bus33/Get Signal Status1'
 * '<S228>' : 'PoseExecutor/Signal to Bus33/Get Signal Type1'
 * '<S229>' : 'PoseExecutor/Signal to Bus33/Get Signal Value1'
 * '<S230>' : 'PoseExecutor/Signal to Bus34/Get Signal RMS1'
 * '<S231>' : 'PoseExecutor/Signal to Bus34/Get Signal Sequence Number'
 * '<S232>' : 'PoseExecutor/Signal to Bus34/Get Signal Status1'
 * '<S233>' : 'PoseExecutor/Signal to Bus34/Get Signal Type1'
 * '<S234>' : 'PoseExecutor/Signal to Bus34/Get Signal Value1'
 * '<S235>' : 'PoseExecutor/Signal to Bus35/Get Signal RMS1'
 * '<S236>' : 'PoseExecutor/Signal to Bus35/Get Signal Sequence Number'
 * '<S237>' : 'PoseExecutor/Signal to Bus35/Get Signal Status1'
 * '<S238>' : 'PoseExecutor/Signal to Bus35/Get Signal Type1'
 * '<S239>' : 'PoseExecutor/Signal to Bus35/Get Signal Value1'
 * '<S240>' : 'PoseExecutor/Signal to Bus4/Get Signal RMS1'
 * '<S241>' : 'PoseExecutor/Signal to Bus4/Get Signal Sequence Number'
 * '<S242>' : 'PoseExecutor/Signal to Bus4/Get Signal Status1'
 * '<S243>' : 'PoseExecutor/Signal to Bus4/Get Signal Type1'
 * '<S244>' : 'PoseExecutor/Signal to Bus4/Get Signal Value1'
 * '<S245>' : 'PoseExecutor/Signal to Bus5/Get Signal RMS1'
 * '<S246>' : 'PoseExecutor/Signal to Bus5/Get Signal Sequence Number'
 * '<S247>' : 'PoseExecutor/Signal to Bus5/Get Signal Status1'
 * '<S248>' : 'PoseExecutor/Signal to Bus5/Get Signal Type1'
 * '<S249>' : 'PoseExecutor/Signal to Bus5/Get Signal Value1'
 * '<S250>' : 'PoseExecutor/Signal to Bus6/Get Signal RMS1'
 * '<S251>' : 'PoseExecutor/Signal to Bus6/Get Signal Sequence Number'
 * '<S252>' : 'PoseExecutor/Signal to Bus6/Get Signal Status1'
 * '<S253>' : 'PoseExecutor/Signal to Bus6/Get Signal Type1'
 * '<S254>' : 'PoseExecutor/Signal to Bus6/Get Signal Value1'
 * '<S255>' : 'PoseExecutor/Signal to Bus7/Get Signal RMS1'
 * '<S256>' : 'PoseExecutor/Signal to Bus7/Get Signal Sequence Number'
 * '<S257>' : 'PoseExecutor/Signal to Bus7/Get Signal Status1'
 * '<S258>' : 'PoseExecutor/Signal to Bus7/Get Signal Type1'
 * '<S259>' : 'PoseExecutor/Signal to Bus7/Get Signal Value1'
 * '<S260>' : 'PoseExecutor/Signal to Bus8/Get Signal RMS1'
 * '<S261>' : 'PoseExecutor/Signal to Bus8/Get Signal Sequence Number'
 * '<S262>' : 'PoseExecutor/Signal to Bus8/Get Signal Status1'
 * '<S263>' : 'PoseExecutor/Signal to Bus8/Get Signal Type1'
 * '<S264>' : 'PoseExecutor/Signal to Bus8/Get Signal Value1'
 * '<S265>' : 'PoseExecutor/Signal to Bus9/Get Signal RMS1'
 * '<S266>' : 'PoseExecutor/Signal to Bus9/Get Signal Sequence Number'
 * '<S267>' : 'PoseExecutor/Signal to Bus9/Get Signal Status1'
 * '<S268>' : 'PoseExecutor/Signal to Bus9/Get Signal Type1'
 * '<S269>' : 'PoseExecutor/Signal to Bus9/Get Signal Value1'
 */
#endif                                 /* RTW_HEADER_PoseExecutor_h_ */
