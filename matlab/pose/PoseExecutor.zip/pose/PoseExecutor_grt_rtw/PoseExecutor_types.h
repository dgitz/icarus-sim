/*
 * PoseExecutor_types.h
 *
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * Code generation for model "PoseExecutor".
 *
 * Model version              : 1.122
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C++ source code generated on : Mon Feb 10 20:47:00 2020
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_PoseExecutor_types_h_
#define RTW_HEADER_PoseExecutor_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#ifndef DEFINED_TYPEDEF_FOR_struct_2fPp7x7bi0ju7exLxtFz0C_
#define DEFINED_TYPEDEF_FOR_struct_2fPp7x7bi0ju7exLxtFz0C_

typedef struct {
  real_T values[94590];
  real_T dimensions;
} struct_2fPp7x7bi0ju7exLxtFz0C;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_Wgs1UNIIN6XWizWoEgEDu_
#define DEFINED_TYPEDEF_FOR_struct_Wgs1UNIIN6XWizWoEgEDu_

typedef struct {
  real_T time[18918];
  struct_2fPp7x7bi0ju7exLxtFz0C signals;
  real_T available;
} struct_Wgs1UNIIN6XWizWoEgEDu;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_lNH6JkfcCmNvugpRU1jWzB_
#define DEFINED_TYPEDEF_FOR_struct_lNH6JkfcCmNvugpRU1jWzB_

typedef struct {
  real_T values[96050];
  real_T dimensions;
} struct_lNH6JkfcCmNvugpRU1jWzB;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_7g45lgOinCvF96v4vleXGF_
#define DEFINED_TYPEDEF_FOR_struct_7g45lgOinCvF96v4vleXGF_

typedef struct {
  real_T time[19210];
  struct_lNH6JkfcCmNvugpRU1jWzB signals;
  real_T available;
} struct_7g45lgOinCvF96v4vleXGF;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_IiuOkAWMi4z4ALWEtiv5S_
#define DEFINED_TYPEDEF_FOR_struct_IiuOkAWMi4z4ALWEtiv5S_

typedef struct {
  real_T values[5];
  real_T dimensions;
} struct_IiuOkAWMi4z4ALWEtiv5S;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_So9XmPVPspyvh7p2pmoGNF_
#define DEFINED_TYPEDEF_FOR_struct_So9XmPVPspyvh7p2pmoGNF_

typedef struct {
  real_T time;
  struct_IiuOkAWMi4z4ALWEtiv5S signals;
  real_T available;
} struct_So9XmPVPspyvh7p2pmoGNF;

#endif

/* Parameters for system: '<Root>/Signal to Bus' */
typedef struct P_SignaltoBus_PoseExecutor_T_ P_SignaltoBus_PoseExecutor_T;

/* Parameters (default storage) */
typedef struct P_PoseExecutor_T_ P_PoseExecutor_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_PoseExecutor_T RT_MODEL_PoseExecutor_T;

#endif                                 /* RTW_HEADER_PoseExecutor_types_h_ */
