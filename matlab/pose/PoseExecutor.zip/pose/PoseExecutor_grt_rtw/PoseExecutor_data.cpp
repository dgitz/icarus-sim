/*
 * PoseExecutor_data.cpp
 *
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * Code generation for model "PoseExecutor".
 *
 * Model version              : 1.122
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C++ source code generated on : Mon Feb 10 20:47:00 2020
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "PoseExecutor.h"
#include "PoseExecutor_private.h"

/* Block parameters (default storage) */
P_PoseExecutor_T PoseExecutorModelClass::PoseExecutor_P = {
  /* Start of '<Root>/Signal to Bus9' */
  {
    /* Expression: 3
     * Referenced by: '<S265>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S267>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S268>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S269>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus9' */

  /* Start of '<Root>/Signal to Bus8' */
  {
    /* Expression: 3
     * Referenced by: '<S260>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S262>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S263>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S264>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus8' */

  /* Start of '<Root>/Signal to Bus7' */
  {
    /* Expression: 3
     * Referenced by: '<S255>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S257>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S258>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S259>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus7' */

  /* Start of '<Root>/Signal to Bus6' */
  {
    /* Expression: 3
     * Referenced by: '<S250>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S252>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S253>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S254>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus6' */

  /* Start of '<Root>/Signal to Bus5' */
  {
    /* Expression: 3
     * Referenced by: '<S245>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S247>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S248>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S249>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus5' */

  /* Start of '<Root>/Signal to Bus4' */
  {
    /* Expression: 3
     * Referenced by: '<S240>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S242>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S243>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S244>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus4' */

  /* Start of '<Root>/Signal to Bus35' */
  {
    /* Expression: 3
     * Referenced by: '<S235>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S237>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S238>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S239>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus35' */

  /* Start of '<Root>/Signal to Bus34' */
  {
    /* Expression: 3
     * Referenced by: '<S230>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S232>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S233>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S234>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus34' */

  /* Start of '<Root>/Signal to Bus33' */
  {
    /* Expression: 3
     * Referenced by: '<S225>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S227>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S228>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S229>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus33' */

  /* Start of '<Root>/Signal to Bus32' */
  {
    /* Expression: 3
     * Referenced by: '<S220>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S222>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S223>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S224>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus32' */

  /* Start of '<Root>/Signal to Bus31' */
  {
    /* Expression: 3
     * Referenced by: '<S215>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S217>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S218>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S219>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus31' */

  /* Start of '<Root>/Signal to Bus30' */
  {
    /* Expression: 3
     * Referenced by: '<S210>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S212>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S213>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S214>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus30' */

  /* Start of '<Root>/Signal to Bus3' */
  {
    /* Expression: 3
     * Referenced by: '<S205>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S207>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S208>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S209>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus3' */

  /* Start of '<Root>/Signal to Bus29' */
  {
    /* Expression: 3
     * Referenced by: '<S200>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S202>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S203>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S204>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus29' */

  /* Start of '<Root>/Signal to Bus28' */
  {
    /* Expression: 3
     * Referenced by: '<S195>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S197>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S198>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S199>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus28' */

  /* Start of '<Root>/Signal to Bus27' */
  {
    /* Expression: 3
     * Referenced by: '<S190>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S192>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S193>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S194>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus27' */

  /* Start of '<Root>/Signal to Bus26' */
  {
    /* Expression: 3
     * Referenced by: '<S185>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S187>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S188>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S189>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus26' */

  /* Start of '<Root>/Signal to Bus25' */
  {
    /* Expression: 3
     * Referenced by: '<S180>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S182>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S183>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S184>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus25' */

  /* Start of '<Root>/Signal to Bus24' */
  {
    /* Expression: 3
     * Referenced by: '<S175>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S177>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S178>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S179>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus24' */

  /* Start of '<Root>/Signal to Bus23' */
  {
    /* Expression: 3
     * Referenced by: '<S170>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S172>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S173>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S174>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus23' */

  /* Start of '<Root>/Signal to Bus22' */
  {
    /* Expression: 3
     * Referenced by: '<S165>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S167>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S168>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S169>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus22' */

  /* Start of '<Root>/Signal to Bus21' */
  {
    /* Expression: 3
     * Referenced by: '<S160>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S162>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S163>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S164>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus21' */

  /* Start of '<Root>/Signal to Bus20' */
  {
    /* Expression: 3
     * Referenced by: '<S155>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S157>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S158>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S159>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus20' */

  /* Start of '<Root>/Signal to Bus2' */
  {
    /* Expression: 3
     * Referenced by: '<S150>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S152>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S153>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S154>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus2' */

  /* Start of '<Root>/Signal to Bus19' */
  {
    /* Expression: 3
     * Referenced by: '<S145>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S147>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S148>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S149>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus19' */

  /* Start of '<Root>/Signal to Bus18' */
  {
    /* Expression: 3
     * Referenced by: '<S140>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S142>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S143>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S144>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus18' */

  /* Start of '<Root>/Signal to Bus17' */
  {
    /* Expression: 3
     * Referenced by: '<S135>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S137>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S138>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S139>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus17' */

  /* Start of '<Root>/Signal to Bus16' */
  {
    /* Expression: 3
     * Referenced by: '<S130>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S132>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S133>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S134>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus16' */

  /* Start of '<Root>/Signal to Bus15' */
  {
    /* Expression: 3
     * Referenced by: '<S125>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S127>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S128>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S129>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus15' */

  /* Start of '<Root>/Signal to Bus14' */
  {
    /* Expression: 3
     * Referenced by: '<S120>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S122>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S123>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S124>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus14' */

  /* Start of '<Root>/Signal to Bus13' */
  {
    /* Expression: 3
     * Referenced by: '<S115>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S117>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S118>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S119>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus13' */

  /* Start of '<Root>/Signal to Bus12' */
  {
    /* Expression: 3
     * Referenced by: '<S110>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S112>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S113>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S114>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus12' */

  /* Start of '<Root>/Signal to Bus11' */
  {
    /* Expression: 3
     * Referenced by: '<S105>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S107>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S108>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S109>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus11' */

  /* Start of '<Root>/Signal to Bus10' */
  {
    /* Expression: 3
     * Referenced by: '<S100>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S102>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S103>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S104>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus10' */

  /* Start of '<Root>/Signal to Bus1' */
  {
    /* Expression: 3
     * Referenced by: '<S95>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S97>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S98>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S99>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<Root>/Signal to Bus1' */

  /* Start of '<Root>/Signal to Bus' */
  {
    /* Expression: 3
     * Referenced by: '<S90>/Constant1'
     */
    3.0,

    /* Expression: 2
     * Referenced by: '<S92>/Constant1'
     */
    2.0,

    /* Expression: 0
     * Referenced by: '<S93>/Constant1'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S94>/Constant1'
     */
    1.0
  }
  /* End of '<Root>/Signal to Bus' */
};
